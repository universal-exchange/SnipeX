# SnipeX
V0.1.0-Beta Build 20200715

© 2020-2020 Xu Rendong. All Rights Reserved.

### Project Summary
Fast Securities Trading System.

### Contact Information
QQ: 277195007, WeChat: ustc_xrd, E-mail: xrd@ustc.edu
