# SnipeX
V0.1.1-Beta Build 20241108

© 2020-2024 Xu Rendong. All Rights Reserved.

### Project Summary
Fast Securities Trading System.

### Contact Information
WeChat：xrd_ustc，~~QQ：277195007~~，~~E-mail：xrd@ustc.edu~~
